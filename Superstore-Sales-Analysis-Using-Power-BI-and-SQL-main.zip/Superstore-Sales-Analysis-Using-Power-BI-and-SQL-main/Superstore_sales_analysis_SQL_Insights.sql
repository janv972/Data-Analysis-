USE superstore_db;

SELECT * FROM superstore;

-- Q1) What percentage of total orders were shipped on the same date?
SELECT
    ROUND((COUNT(DISTINCT Order_ID) * 100.0 / (SELECT COUNT(DISTINCT Order_ID) FROM superstore)), 2) AS Same_Day_Shipping_Percentage
FROM superstore
WHERE Order_Date = Ship_Date;

-- Q2) Name top 3 customers with highest total value of orders?
SELECT TOP 3
    Customer_Name,
    ROUND(SUM(sales), 3) AS TotalOrderValue
FROM superstore
GROUP BY Customer_Name
ORDER BY TotalOrderValue DESC;

-- Q3) Find the top 5 items with the highest average sales per day?
SELECT TOP 5
    Product_ID,
    ROUND(AVG(sales), 3) AS Average_Sales
FROM superstore
GROUP BY Product_ID
ORDER BY Average_Sales DESC;

-- Q4) Find the average order value for each customer and rank them?
SELECT
    Customer_Name,
    ROUND(AVG(sales), 3) AS avg_order_value,
    DENSE_RANK() OVER (ORDER BY AVG(sales) DESC) AS sales_rank
FROM superstore
GROUP BY Customer_Name;

-- Q5) Customers who ordered highest and lowest orders from each city?
WITH cte AS (
    SELECT
        City,
        MAX(sales) AS highest_order,
        MIN(sales) AS lowest_order
    FROM superstore
    GROUP BY City
),
highest_orders AS (
    SELECT
        s.City,
        cte.highest_order,
        s.Customer_Name AS highest_order_customer
    FROM superstore s
    INNER JOIN cte ON s.City = cte.City AND s.Sales = cte.highest_order
),
lowest_orders AS (
    SELECT
        s.City,
        cte.lowest_order,
        s.Customer_Name AS lowest_order_customer
    FROM superstore s
    INNER JOIN cte ON s.City = cte.City AND s.Sales = cte.lowest_order
)
SELECT
    h.City,
    h.highest_order,
    h.highest_order_customer,
    l.lowest_order,
    l.lowest_order_customer
FROM highest_orders h
INNER JOIN lowest_orders l ON h.City = l.City
ORDER BY h.City;

-- Q6) Most demanded sub-category in the West region?
SELECT TOP 1
    Sub_Category,
    ROUND(SUM(sales), 3) AS total_quantity
FROM superstore
WHERE Region = 'West'
GROUP BY Sub_Category
ORDER BY total_quantity DESC;

-- Q7) Which order has the highest number of items?
SELECT TOP 1
    order_id,
    COUNT(order_id) AS num_item
FROM superstore
GROUP BY order_id
ORDER BY num_item DESC;

-- Q8) Which order has the highest cumulative value?
SELECT TOP 1
    order_id,
    ROUND(SUM(sales), 3) AS order_value
FROM superstore
GROUP BY order_id
ORDER BY order_value DESC;

-- Q9) Which segment’s order is more likely to be shipped via first class?
SELECT
    segment,
    COUNT(order_id) AS num_of_orders
FROM superstore
WHERE ship_mode = 'First Class'
GROUP BY segment
ORDER BY num_of_orders DESC;

-- Q10) Which city contributes the least to total revenue?
SELECT TOP 1
    city,
    ROUND(SUM(sales), 3) AS TotalSales
FROM superstore
GROUP BY city
ORDER BY TotalSales ASC;

-- Q11) Average time for orders to get shipped after being placed?
SELECT
    AVG(DATEDIFF(day, order_date, ship_date)) AS avg_ship_time
FROM superstore;

-- Q12) Which segment places the most and largest individual orders from each state?
WITH cte AS (
    SELECT
        state,
        segment,
        COUNT(order_id) AS num_orders,
        RANK() OVER (PARTITION BY state ORDER BY COUNT(order_id) DESC) AS state_rank
    FROM superstore
    GROUP BY state, segment
)
SELECT
    state,
    segment
FROM cte
WHERE state_rank = 1;

-- Q13) Customers who ordered on 3 consecutive days with each order > 50 value?
WITH cte AS (
    SELECT
        Customer_ID,
        Customer_Name,
        Order_Date,
        SUM(sales) AS order_value,
        LAG(Order_Date, 1) OVER (PARTITION BY Customer_ID ORDER BY Order_Date) AS prev_day,
        LAG(Order_Date, 2) OVER (PARTITION BY Customer_ID ORDER BY Order_Date) AS prev_2_days
    FROM superstore
    GROUP BY Customer_ID, Customer_Name, Order_Date
    HAVING SUM(sales) > 50
)
SELECT DISTINCT Customer_ID, Customer_Name
FROM cte
WHERE DATEDIFF(day, prev_day, Order_Date) = 1 AND DATEDIFF(day, prev_2_days, prev_day) = 1;

-- Q14) Maximum number of days for continuously rising sales?
WITH sales_sequence AS (
    SELECT
        Order_Date,
        SUM(Sales) AS TotalSales,
        ROW_NUMBER() OVER (ORDER BY Order_Date) AS rn
    FROM superstore
    GROUP BY Order_Date
),
rising_days AS (
    SELECT
        s1.Order_Date,
        COUNT(*) AS rising_day_count
    FROM sales_sequence s1
    INNER JOIN sales_sequence s2
    ON s1.TotalSales < s2.TotalSales AND s1.rn < s2.rn
    GROUP BY s1.Order_Date
)
SELECT MAX(rising_day_count) AS max_rising_days FROM rising_days;
